# Programming-Languages-Project
This REPO contains projects of PL lab

NewsJsonCode.py contains main code &&
newspost.json contains the output of above file.
# Date filter has been applied to scrape post till a specified date
Please read internal documentation in NewsJsonCode.py.

jsonXloader.py is the post formatter to further process post contents according to needs.
scrapednews.json is the REFINED >> output #custom changes possible
NOTE: to use jsonXloader.py makesure that all the above mentioned files are in same directory.

Contribution:
  Nikhil: 
  
    + threading of news scraping (n threads = n times speed )
    
    + date filter to scrape posts till specific date
    
    + reordering of json to display Title>Date>link>Newscontent in order.
    
    + JsonXloader.py which gives access to further process data
    
    + needed optimizations for time and space complexity.
    
  Shivam Jha:
  
    (please add your contribution here)
    
  Deepanshu Jain:
  
    (please add your contribution here)

    

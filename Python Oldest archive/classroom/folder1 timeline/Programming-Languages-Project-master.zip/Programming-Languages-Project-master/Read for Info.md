# Programming-Languages-Project
This contains projects of PL lab: 

1)"Final PL project by-Shivam Jha, Deepanshu Jain, Nikhil Swami.ipynb":
    This file contains the code with output of the project.
    
2)"Programming Languages The Hindu Scrape.py":
    This file contains just the code for the project without output for quick load.
    
3)l1,l2, l3, l4, l5 are JSON files with the scraped data of the project.

4)Rest are Twitter Project Files

